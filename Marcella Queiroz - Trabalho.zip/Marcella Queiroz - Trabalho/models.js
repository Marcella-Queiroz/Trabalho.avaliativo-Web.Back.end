let users = [];
let recipes = [];

module.exports = {
  users,
  recipes,
};
