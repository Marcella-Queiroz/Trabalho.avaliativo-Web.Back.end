const express = require('express');
const controllers = require('./controllers');
const middlewares = require('./middlewares');

const router = express.Router();

router.post('/register', controllers.registerUser);
router.post('/login', controllers.loginUser);

router.use(middlewares.authenticate);

router.get('/recipes', controllers.getAllRecipes);
router.get('/recipes/:id', controllers.getRecipe);
router.post('/recipes', controllers.createRecipe);
router.put('/recipes/:id', controllers.updateRecipe);
router.delete('/recipes/:id', controllers.deleteRecipe);

module.exports = router;
