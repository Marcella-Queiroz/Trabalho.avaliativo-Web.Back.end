const jwt = require('jsonwebtoken');
const { users } = require('./models');

const secretKey = 'chave-secreta';

function authenticate(req, res, next) {
  const token = req.headers.authorization;

  if (!token) {
    return res.status(401).json({ error: 'Não autorizado' });
  }

  try {
    const decodedToken = jwt.verify(token, secretKey);
    const userId = decodedToken.userId;

    const user = users.find((u) => u.id === userId);
    if (!user) {
      return res.status(401).json({ error: 'Não autorizado' });
    }

    req.userId = userId;

    next();
  } catch (error) {
    return res.status(401).json({ error: 'Não autorizado' });
  }
}

module.exports = {
  authenticate,
};
