const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { users, recipes } = require('./models');

const secretKey = 'chave-secreta';

function registerUser(req, res) {
  const { name, email, password } = req.body;

  const existingUser = users.find((user) => user.email === email);
  if (existingUser) {
    return res.status(400).json({ error: 'Email já em uso' });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);

  const newUser = {
    id: users.length + 1,
    name,
    email,
    password: hashedPassword,
  };

  users.push(newUser);

  return res.status(201).json({ message: 'Usuário registrado com sucesso' });
}

function loginUser(req, res) {
  const { email, password } = req.body;

  const user = users.find((u) => u.email === email);
  if (!user) {
    return res.status(401).json({ error: 'E-mail ou senha inválidos' });
  }

  const passwordMatch = bcrypt.compareSync(password, user.password);
  if (!passwordMatch) {
    return res.status(401).json({ error: 'E-mail ou senha inválidos' });
  }

  const token = jwt.sign({ userId: user.id }, secretKey);

  return res.status(200).json({ token });
}

function getAllRecipes(req, res) {

  const userId = req.userId;
  const userRecipes = recipes.filter((recipe) => recipe.userId === userId);

  return res.status(200).json(userRecipes);
}

function getRecipe(req, res) {
  const { id } = req.params;

  const recipe = recipes.find((r) => r.id === parseInt(id));
  if (!recipe) {
    return res.status(404).json({ error: 'Receita não encontrada' });
  }

  if (recipe.userId !== req.userId) {
    return res.status(403).json({ error: 'Não autorizado' });
  }

  return res.status(200).json(recipe);
}

function createRecipe(req, res) {
  const { name, description, prepTime } = req.body;

  const newRecipe = {
    id: recipes.length + 1,
    name,
    description,
    prepTime,
    userId: req.userId,
  };

  recipes.push(newRecipe);

  return res.status(201).json({ message: 'Receita criada com sucesso' });
}

function updateRecipe(req, res) {
  const { id } = req.params;
  const { name, description, prepTime } = req.body;

  const recipeIndex = recipes.findIndex((r) => r.id === parseInt(id));
  if (recipeIndex === -1) {
    return res.status(404).json({ error: 'Receita não encontrada' });
  }

  const recipe = recipes[recipeIndex];

  if (recipe.userId !== req.userId) {
    return res.status(403).json({ error: 'Não autorizado' });
  }

  recipe.name = name;
  recipe.description = description;
  recipe.prepTime = prepTime;

  return res.status(200).json({ message: 'Receita atualizada com sucesso' });
}

function deleteRecipe(req, res) {
  const { id } = req.params;

  const recipeIndex = recipes.findIndex((r) => r.id === parseInt(id));
  if (recipeIndex === -1) {
    return res.status(404).json({ error: 'Receita não encontrada' });
  }

  const recipe = recipes[recipeIndex];

  if (recipe.userId !== req.userId) {
    return res.status(403).json({ error: 'Não autorizado' });
  }

  recipes.splice(recipeIndex, 1);

  return res.status(200).json({ message: 'Receita excluída com sucesso' });
}

module.exports = {
  registerUser,
  loginUser,
  getAllRecipes,
  getRecipe,
  createRecipe,
  updateRecipe,
  deleteRecipe,
};
